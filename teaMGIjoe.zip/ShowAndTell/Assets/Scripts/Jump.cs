﻿using UnityEngine;
using System.Collections;

public class Jump : MonoBehaviour {

    public bool left = true;
    public bool right = true;

}
