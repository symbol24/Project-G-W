﻿using UnityEngine;
using System.Collections;

public class Wind : MonoBehaviour {

    public bool left = true;
    public bool right = true;

}
